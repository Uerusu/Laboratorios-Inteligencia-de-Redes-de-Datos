from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Iterable

import numpy as np
import psycopg
import requests
from dotenv import load_dotenv
from pgvector.psycopg import register_vector


BASE_DIR = Path(__file__).resolve().parent.parent
DOCUMENTOS_DIR = BASE_DIR / "documentos"

load_dotenv(BASE_DIR / ".env")

DATABASE_URL = os.getenv("DATABASE_URL")
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434").rstrip("/")
EMBED_MODEL = os.getenv("EMBED_MODEL", "qwen3-embedding:0.6b")

DIMENSION_EMBEDDING = 1024
TAMANO_FRAGMENTO = 180
SOLAPAMIENTO = 30
TAMANO_LOTE = 8


def validar_configuracion() -> None:
    if not DATABASE_URL:
        raise RuntimeError("Falta DATABASE_URL en el archivo .env")

    if not DOCUMENTOS_DIR.exists():
        raise RuntimeError(
            f"No existe el directorio de documentos: {DOCUMENTOS_DIR}"
        )


def fragmentar(
    texto: str,
    max_palabras: int = TAMANO_FRAGMENTO,
    solapamiento: int = SOLAPAMIENTO,
) -> list[str]:
    palabras = texto.split()
    if not palabras:
        return []

    fragmentos: list[str] = []
    inicio = 0

    while inicio < len(palabras):
        fin = min(inicio + max_palabras, len(palabras))
        fragmento = " ".join(palabras[inicio:fin]).strip()

        if fragmento:
            fragmentos.append(fragmento)

        if fin >= len(palabras):
            break

        inicio = fin - solapamiento

    return fragmentos


def dividir_lotes(
    elementos: list[str],
    tamano: int,
) -> Iterable[list[str]]:
    for inicio in range(0, len(elementos), tamano):
        yield elementos[inicio:inicio + tamano]


def generar_embeddings(textos: list[str]) -> list[np.ndarray]:
    vectores: list[np.ndarray] = []

    for lote in dividir_lotes(textos, TAMANO_LOTE):
        respuesta = requests.post(
            f"{OLLAMA_URL}/api/embed",
            json={
                "model": EMBED_MODEL,
                "input": lote,
            },
            timeout=300,
        )
        respuesta.raise_for_status()

        datos = respuesta.json()
        embeddings = datos.get("embeddings")

        if not embeddings or len(embeddings) != len(lote):
            raise RuntimeError(
                "Ollama no devolvió la cantidad esperada de embeddings"
            )

        for embedding in embeddings:
            if len(embedding) != DIMENSION_EMBEDDING:
                raise RuntimeError(
                    "Dimensión inesperada: "
                    f"{len(embedding)}; se esperaban "
                    f"{DIMENSION_EMBEDDING}"
                )

            vectores.append(
                np.asarray(embedding, dtype=np.float32)
            )

    return vectores


def preparar_registros() -> list[dict]:
    registros: list[dict] = []

    archivos = sorted(DOCUMENTOS_DIR.glob("*.md"))
    if not archivos:
        raise RuntimeError(
            f"No se encontraron archivos Markdown en {DOCUMENTOS_DIR}"
        )

    for archivo in archivos:
        texto = archivo.read_text(encoding="utf-8")
        fragmentos = fragmentar(texto)

        for numero, contenido in enumerate(fragmentos, start=1):
            contenido_hash = hashlib.sha256(
                f"{archivo.name}:{numero}:{contenido}".encode("utf-8")
            ).hexdigest()

            registros.append(
                {
                    "fuente": archivo.name,
                    "fragmento_nro": numero,
                    "contenido": contenido,
                    "contenido_hash": contenido_hash,
                }
            )

    return registros


def crear_esquema(cursor: psycopg.Cursor) -> None:
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS documento_fragmento (
            id BIGSERIAL PRIMARY KEY,
            fuente TEXT NOT NULL,
            fragmento_nro INTEGER NOT NULL,
            contenido TEXT NOT NULL,
            contenido_hash CHAR(64) NOT NULL UNIQUE,
            embedding VECTOR(1024) NOT NULL,
            creado_en TIMESTAMPTZ NOT NULL DEFAULT now()
        )
        """
    )


def main() -> None:
    validar_configuracion()
    registros = preparar_registros()
    textos = [registro["contenido"] for registro in registros]

    print(f"Documentos por indexar: {len(list(DOCUMENTOS_DIR.glob('*.md')))}")
    print(f"Fragmentos generados: {len(registros)}")
    print(f"Modelo de embeddings: {EMBED_MODEL}")

    embeddings = generar_embeddings(textos)

    with psycopg.connect(DATABASE_URL) as conexion:
        register_vector(conexion)

        with conexion.cursor() as cursor:
            crear_esquema(cursor)

            # Para que cada ejecución refleje exactamente los documentos
            # actuales del directorio.
            cursor.execute(
                "TRUNCATE TABLE documento_fragmento RESTART IDENTITY"
            )

            for registro, embedding in zip(
                registros,
                embeddings,
                strict=True,
            ):
                cursor.execute(
                    """
                    INSERT INTO documento_fragmento (
                        fuente,
                        fragmento_nro,
                        contenido,
                        contenido_hash,
                        embedding
                    )
                    VALUES (%s, %s, %s, %s, %s)
                    """,
                    (
                        registro["fuente"],
                        registro["fragmento_nro"],
                        registro["contenido"],
                        registro["contenido_hash"],
                        embedding,
                    ),
                )

    print("Carga finalizada correctamente.")


if __name__ == "__main__":
    main()
