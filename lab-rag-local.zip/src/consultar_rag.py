from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import psycopg
import requests
from dotenv import load_dotenv
from pgvector.psycopg import register_vector


BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

DATABASE_URL = os.getenv("DATABASE_URL")
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434").rstrip("/")
CHAT_MODEL = os.getenv("CHAT_MODEL", "qwen3:4b-instruct")
EMBED_MODEL = os.getenv("EMBED_MODEL", "qwen3-embedding:0.6b")
TOP_K = int(os.getenv("TOP_K", "3"))

INSTRUCCION_BUSQUEDA = (
    "Instruct: Given a question in Spanish about information "
    "technology services, retrieve passages that answer the question.\n"
    "Query: "
)


def validar_configuracion() -> None:
    if not DATABASE_URL:
        raise RuntimeError("Falta DATABASE_URL en el archivo .env")


def generar_embedding_pregunta(pregunta: str) -> np.ndarray:
    texto_busqueda = f"{INSTRUCCION_BUSQUEDA}{pregunta}"

    respuesta = requests.post(
        f"{OLLAMA_URL}/api/embed",
        json={
            "model": EMBED_MODEL,
            "input": texto_busqueda,
        },
        timeout=300,
    )
    respuesta.raise_for_status()

    datos = respuesta.json()
    embeddings = datos.get("embeddings")

    if not embeddings:
        raise RuntimeError("Ollama no devolvió el embedding")

    return np.asarray(embeddings[0], dtype=np.float32)


def recuperar_fragmentos(
    pregunta: str,
) -> list[dict]:
    embedding = generar_embedding_pregunta(pregunta)

    with psycopg.connect(DATABASE_URL) as conexion:
        register_vector(conexion)

        with conexion.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    fuente,
                    fragmento_nro,
                    contenido,
                    1 - (embedding <=> %s) AS similitud
                FROM documento_fragmento
                ORDER BY embedding <=> %s
                LIMIT %s
                """,
                (embedding, embedding, TOP_K),
            )

            filas = cursor.fetchall()

    return [
        {
            "fuente": fila[0],
            "fragmento_nro": fila[1],
            "contenido": fila[2],
            "similitud": float(fila[3]),
        }
        for fila in filas
    ]


def construir_contexto(fragmentos: list[dict]) -> str:
    bloques: list[str] = []

    for indice, fragmento in enumerate(fragmentos, start=1):
        etiqueta = (
            f"Fuente {indice}: {fragmento['fuente']}"
            f"#fragmento-{fragmento['fragmento_nro']}"
        )

        bloques.append(
            f"[{etiqueta}]\n{fragmento['contenido']}"
        )

    return "\n\n".join(bloques)


def generar_respuesta(
    pregunta: str,
    fragmentos: list[dict],
) -> str:
    contexto = construir_contexto(fragmentos)

    mensaje_sistema = (
        "Usted es un asistente de soporte técnico. "
        "Responda únicamente con información contenida en el contexto. "
        "Si el contexto no permite responder, indique exactamente: "
        "\"No hay información suficiente en los documentos.\" "
        "Cite las fuentes mediante [Fuente 1], [Fuente 2], etc. "
        "No invente procedimientos, comandos, direcciones ni políticas. "
        "Responda en español de manera clara y breve."
    )

    mensaje_usuario = (
        f"CONTEXTO:\n{contexto}\n\n"
        f"PREGUNTA:\n{pregunta}"
    )

    respuesta = requests.post(
        f"{OLLAMA_URL}/api/chat",
        json={
            "model": CHAT_MODEL,
            "messages": [
                {
                    "role": "system",
                    "content": mensaje_sistema,
                },
                {
                    "role": "user",
                    "content": mensaje_usuario,
                },
            ],
            "stream": False,
            "options": {
                "temperature": 0.1,
                "num_ctx": 4096,
            },
        },
        timeout=600,
    )
    respuesta.raise_for_status()

    datos = respuesta.json()
    return datos["message"]["content"].strip()


def obtener_pregunta() -> str:
    if len(sys.argv) > 1:
        return " ".join(sys.argv[1:]).strip()

    return input("Pregunta: ").strip()


def main() -> None:
    validar_configuracion()
    pregunta = obtener_pregunta()

    if not pregunta:
        raise RuntimeError("La pregunta no puede estar vacía")

    fragmentos = recuperar_fragmentos(pregunta)

    print("\nFragmentos recuperados:")
    for indice, fragmento in enumerate(fragmentos, start=1):
        print(
            f"{indice}. {fragmento['fuente']} "
            f"(similitud={fragmento['similitud']:.4f})"
        )

    respuesta = generar_respuesta(pregunta, fragmentos)

    print("\nRespuesta RAG:")
    print(respuesta)


if __name__ == "__main__":
    main()
