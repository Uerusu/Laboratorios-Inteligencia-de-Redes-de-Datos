# Integración y diagnóstico del SSO

Una integración OIDC requiere un identificador de cliente, un secreto cuando corresponda, una URI de redirección registrada y la URL de descubrimiento del proveedor. El valor redirect_uri enviado por la aplicación debe coincidir exactamente con una URI autorizada, incluyendo protocolo, dominio, puerto y ruta.

El error invalid_redirect_uri suele indicar una diferencia entre la URI enviada y la configurada. También se deben revisar la sincronización de hora, la validez de los certificados, el flujo OIDC utilizado y los registros tanto de la aplicación como del proveedor de identidad.
