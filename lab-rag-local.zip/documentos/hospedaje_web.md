# Procedimiento básico para hospedaje web

Un error HTTP 503 indica que el servicio no se encuentra disponible temporalmente. Antes de reiniciar componentes se debe comprobar si el servidor web responde, si el proceso PHP-FPM está activo, si existe espacio libre en disco y si la base de datos acepta conexiones. También debe revisarse si el error afecta un único sitio o toda la plataforma.

Cuando el sitio muestra errores después de una actualización, se debe revisar el registro de errores de la aplicación y del servidor web. No se recomienda restaurar una copia ni modificar archivos antes de conservar la evidencia necesaria. Si se sospecha una vulneración, el sitio debe aislarse, conservar los registros y solicitar una copia limpia al responsable.
