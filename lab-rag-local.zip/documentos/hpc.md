# Atención de solicitudes e incidentes de HPC

Cuando un trabajo permanece en estado pendiente, se debe consultar la razón indicada por el planificador. Entre las causas comunes se encuentran falta de recursos, límites de calidad de servicio, dependencia de otro trabajo o solicitud de una partición no disponible. Los comandos de diagnóstico pueden incluir squeue, sinfo y scontrol show job.

Para solicitar acceso al clúster, la persona debe indicar el proyecto de investigación, los recursos aproximados, el software requerido y si utilizará CPU o GPU. No se deben ejecutar procesos intensivos directamente en el nodo de acceso. Los cálculos deben enviarse mediante el planificador de trabajos.
