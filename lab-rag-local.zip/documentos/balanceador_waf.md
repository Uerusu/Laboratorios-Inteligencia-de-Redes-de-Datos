# Diagnóstico de balanceador y WAF

Los errores HTTP 502 y 503 publicados por un balanceador pueden originarse en un backend no saludable, un puerto incorrecto, un tiempo de espera agotado o la ausencia de servidores disponibles. Se debe comprobar el estado del monitor, la conectividad desde el balanceador hacia el backend y la respuesta directa del servicio.

Cuando el WAF bloquea una solicitud, se debe registrar la fecha, la hora, la dirección solicitada, el método HTTP, el código de respuesta y el identificador de correlación del evento. Una exclusión debe limitarse a la regla y ruta estrictamente necesarias. No se recomienda deshabilitar toda la política de seguridad para resolver un caso particular.
