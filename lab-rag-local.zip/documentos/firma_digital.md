# Diagnóstico básico de firma digital

Antes de probar una firma digital se debe comprobar que el certificado se encuentre vigente, que el dispositivo criptográfico sea reconocido, que los controladores estén instalados y que la aplicación pueda acceder al proveedor criptográfico. También se debe verificar la fecha y hora del equipo.

Si la firma falla, se debe registrar el mensaje exacto, el sistema operativo, la versión de Java o de la aplicación, el tipo de certificado y el paso donde ocurre el error. No se debe solicitar ni copiar la clave privada de la persona usuaria. Las pruebas deben utilizar certificados y ambientes destinados para simulación cuando estén disponibles.
